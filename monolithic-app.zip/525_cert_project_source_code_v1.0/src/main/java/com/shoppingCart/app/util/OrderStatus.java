package com.shoppingCart.app.util;

public enum OrderStatus {

	NEW, HOLD, SHIPPED, DELIVERED, CLOSED;

}
